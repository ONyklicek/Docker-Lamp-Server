<?php
phpinfo();

